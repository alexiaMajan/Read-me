package patient;

class Procedure {
    private String procedureName;
    private String procedureDate;
    private String doctorsName;
    private double procedureCharges;

    // Constructors
    public Procedure() {
    }

    public Procedure(String procedureName, String procedureDate) {
        this.procedureName = procedureName;
        this.procedureDate = procedureDate;
    }

    public Procedure(String procedureName, String procedureDate, String doctorsName, double procedureCharges) {
        this.procedureName = procedureName;
        this.procedureDate = procedureDate;
        this.doctorsName = doctorsName;
        this.procedureCharges = procedureCharges;
    }

    // accessors and Mutators 
    public String getProcedureName() {
        return procedureName;
    }

    public String getProcedureDate() {
        return procedureDate;
    }

    public String getdoctorsName() {
        return doctorsName;
    }

    public double getProcedureCharges() {
        return procedureCharges;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public void setProcedureDate(String procedureDate) {
        this.procedureDate = procedureDate;
    }

    public void setdoctorsName(String doctorsName) {
        this.doctorsName = doctorsName;
    }

    public void setProcedureCharges(double procedureCharges) {
        this.procedureCharges = procedureCharges;
    }

   
    // toString method to display procedure information
    @Override
    public String toString() {
        return  "    " + "Procedure Information:\n" +
        		"    " + "Name: " + procedureName + "\n" +
        		"    " + "Date: " + procedureDate + "\n" +
        		"    " + "Practitioner: " + doctorsName + "\n" +
        		"    " + "Charges: $" + (procedureCharges);
    }
}
