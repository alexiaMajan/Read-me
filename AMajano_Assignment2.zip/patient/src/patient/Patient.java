package patient;

import java.util.Scanner;
//Patient class
class Patient {
 private String first;
 private String middle;
 private String last;
 private String stAddress;
 private String city;
 private String state;
 private String zipCode;
 private String phoneNum;
 private String emContactName;
 private String emContactPhone;

 // Constructors
 public Patient() {
 }

 	Scanner keys = new Scanner(System.in);
 	
 public Patient(String first, String middle, String last) {
     this.first = first;
     this.middle = middle;
     this.last = last;
 }

 public Patient(String first, String middle, String last, String stAddress,
                String city, String state, String zipCode, String phoneNum,
                String emContactName, String emContactPhone) {
     this.first = first;
     this.middle = middle;
     this.last = last;
     this.stAddress = stAddress;
     this.city = city;
     this.state = state;
     this.zipCode = zipCode;
     this.phoneNum = phoneNum;
     this.emContactName = emContactName;
     this.emContactPhone = emContactPhone;
 }

//accessors
 public String getfirst() {
	
	 return first;
 }
 public String getmiddle() {
	
	 return middle;
 }

 public String getlast() {
	 return last;
 }
 public String getstAddress() {
	 return stAddress;
 }
 public String getcity() {
	 return city;
 }
 public String getstate() {
	 return state;
 }
 public String getzipCode() {
	 return zipCode;
 }
public String phoneNum() {
	return phoneNum;
}
public String emContactName() {
	return emContactName;
}

 // Build full name
 public String buildFullName() {
	 System.out.print("First name: ");
	 String first = keys.nextLine();
	 System.out.print("Middle name: ");
	 String middle = keys.nextLine();
	 System.out.print("Last name: ");
	 String last = keys.nextLine();
     return first + " " + middle + " " + last;
 }

 // Build address
 public String buildAddress() {
	 System.out.print("Street Address:  ");
	 String stAddress = keys.nextLine();
	 System.out.print("City: ");
	 String city = keys.nextLine();
	 System.out.print("State: ");
	 String state = keys.nextLine();
	 System.out.print("ZipCode: ");
	 String zipCode = keys.nextLine();
     return stAddress + " " + city + " " + state + " " + zipCode;
 }

 // Build emergency contact information
 public String buildEmergencyContact() {
     return emContactName + " " + emContactPhone;
 }

 // toString method to display patient information
 
 public String toString() {
     return  "\n Patient Info:\n" +
    		 " " + "Full Name: " + buildFullName() + "\n" +
    		 " " + "Address: " + buildAddress() + "\n" +
    		 " " + "Phone Number: " + phoneNum + "\n" +
    		 " " + "Emergency Contact: " + buildEmergencyContact();
 }
}
