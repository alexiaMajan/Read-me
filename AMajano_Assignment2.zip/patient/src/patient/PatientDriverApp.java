package patient;

import java.text.DecimalFormat;

public class PatientDriverApp {
    public static void main(String[] args) {
        
    	
    	// Create object
        Patient patient = new Patient("Jenny ", "Elaine", "Santori", "123 Main Street", "Mytown", 
        		"CA", "01234", "321-123-7890", "bill sunny", "888-666-1212");

        // Create three procedure objects using different constructors
        Procedure procedure1 = new Procedure("Operation", "03/23/2019","Dr.frank", 9000.0);
        Procedure procedure2 = new Procedure("X-Ray", "04/20/2019", "Dr. Smith", 4600.43);
        Procedure procedure3 = new Procedure("Physical Exam", "12/25/2021", "Dr. luffy", 1200.75);
       
        // Display info
        displayPatient(patient);
        System.out.println( "\n");
        // Display procedure information
        displayProcedure(procedure1);
        System.out.println( "\n");
        displayProcedure(procedure2);
        System.out.println( "\n");
        displayProcedure(procedure3);
        System.out.println( "\n");
        // Calculating the charges
        double totalCharges = calculateTotalCharges(procedure1, procedure2, procedure3);
        System.out.println("Total Charges: $" + (totalCharges)+ "\n");
       
        System.out.println("Student Name: Alexia Majano");
        System.out.println("Due Date:" + "09/25/2023");
        System.out.println("MC#:"+ "21144849");
    }

    //displays the toString info
    public static void displayPatient(Patient patient) {
        System.out.println(patient.toString());
    }

    // displays to string procedure info
    public static void displayProcedure(Procedure procedure) {
        System.out.println(procedure.toString());
    }

    //calculate total charges
    public static double calculateTotalCharges(Procedure procedure1, Procedure procedure2, Procedure procedure3) {
        double totalCharges = procedure1.getProcedureCharges() + procedure2.getProcedureCharges() + procedure3.getProcedureCharges();
        return totalCharges;
    }

    // two decimal points using import
    public static String formatTotalCharges(double totalCharges) {
       
        DecimalFormat decimalformat= new decimalFormat("#.##");
        decimalFormat.setGroupingUsed(true);
        decimalFormat.setGroupingSize(2);
        for(double d : totalCharges) {
        	System.out.println(decimalFormat.format(d));
        }
               
    }
}